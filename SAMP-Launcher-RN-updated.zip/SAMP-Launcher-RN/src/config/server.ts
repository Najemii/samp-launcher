// عنوان السيرفر الذي يتصل به اللاعب
export const SERVER_HOST = '45.138.16.241';
export const SERVER_PORT = 8365;
export const SERVER_NAME = 'SpeedLife';
