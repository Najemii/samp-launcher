import { URL_DISTRIBUTION } from '@env';
import axios from 'axios';
import { CacheType } from '../actions/loaderActions';
import { SERVER_HOST, SERVER_NAME, SERVER_PORT } from '../config/server';

export const DistributionService = {
  async get() {
    const response = await axios
      .get<DistributionResponseType>(URL_DISTRIBUTION)
      .then(res => res.data);

    // نعرض سيرفرنا فقط في القائمة
    response.servers = [
      {
        id: 1,
        show: true,
        version: '',
        icon: '',
        events: [],
        slot: 1000,
        bonus: false,
        name: SERVER_NAME,
        description: '',
        address: `${SERVER_HOST}:${SERVER_PORT}`,
        sampVersion: '',
      },
    ];
    return response;
  },
};

type DistributionResponseType = DistributionResponse & {
  cache: CacheType[];
};

export type DistributionResponse = {
  cdnLauncher: string;
  cdnCache: string;
  cacheMode: CacheType[];
  rss: string;
  versionHash: string;
  packageName: string;
  projectName: string;
  servers: ServerType[];
  launcher: LauncherType;
  filesContinue: FileContinueType;
};

type FileContinueType = string[];

type LauncherType = {
  appVersion: string;
  name: string;
  hash: string;
  bytes: number;
  size: string;
};

type EventType = {
  title: string;
  style: 'red' | 'blue';
};

export type ServerType = {
  id: number;
  show: boolean;
  version: string;
  icon: string;
  events: EventType[];
  slot: number;
  bonus: boolean;
  name: string;
  description: string;
  address: string;
  sampVersion: string;
};
