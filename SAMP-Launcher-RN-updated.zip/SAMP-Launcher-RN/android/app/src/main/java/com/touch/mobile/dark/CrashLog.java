package com.touch.mobile.dark;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** يكتب ملف تشخيص: Android/data/<package>/files/launcher_debug.txt */
public class CrashLog {
    private static final String PATH =
            "/storage/emulated/0/Android/data/com.touch.mobile.dark/files/launcher_debug.txt";

    public static synchronized void log(String msg) {
        try {
            File f = new File(PATH);
            File dir = f.getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();
            FileWriter w = new FileWriter(f, true);
            String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            w.write(t + "  " + msg + "\n");
            w.close();
        } catch (Throwable ignored) {
        }
    }

    public static void log(String msg, Throwable e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        log(msg + "\n" + sw);
    }

    private static String reasonName(int r) {
        switch (r) {
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH (java)";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            default: return "UNKNOWN(" + r + ")";
        }
    }

    /** يقرأ سبب إغلاق العملية السابقة (أندرويد 11+) ويكتبه في الملف */
    public static void logLastExits(Context ctx) {
        if (Build.VERSION.SDK_INT < 30) {
            log("exit info needs Android 11+");
            return;
        }
        try {
            SharedPreferences sp = ctx.getSharedPreferences("crashlog", Context.MODE_PRIVATE);
            long last = sp.getLong("lastExitTs", 0);
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(ctx.getPackageName(), 0, 5);
            long newest = last;
            for (ApplicationExitInfo i : list) {
                if (i.getTimestamp() <= last) continue;
                if (i.getTimestamp() > newest) newest = i.getTimestamp();
                log("PREVIOUS EXIT: reason=" + reasonName(i.getReason())
                        + " status=" + i.getStatus()
                        + " process=" + i.getProcessName()
                        + " desc=" + i.getDescription());
                if (i.getReason() == ApplicationExitInfo.REASON_CRASH_NATIVE) {
                    try {
                        InputStream is = i.getTraceInputStream();
                        if (is != null) {
                            ByteArrayOutputStream bo = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192];
                            int n;
                            int total = 0;
                            while ((n = is.read(buf)) > 0 && total < 400000) {
                                bo.write(buf, 0, n);
                                total += n;
                            }
                            is.close();
                            log("NATIVE TRACE (printable strings):\n" + printable(bo.toByteArray()));
                        } else {
                            log("no native trace stream");
                        }
                    } catch (Throwable t) {
                        log("trace read failed", t);
                    }
                }
            }
            sp.edit().putLong("lastExitTs", newest).apply();
        } catch (Throwable t) {
            log("logLastExits failed", t);
        }
    }

    private static String printable(byte[] data) {
        StringBuilder out = new StringBuilder();
        StringBuilder cur = new StringBuilder();
        for (byte b : data) {
            if (b >= 32 && b < 127) {
                cur.append((char) b);
            } else {
                if (cur.length() >= 5) {
                    out.append(cur).append('\n');
                    if (out.length() > 12000) return out.toString();
                }
                cur.setLength(0);
            }
        }
        if (cur.length() >= 5) out.append(cur);
        return out.toString();
    }

    public static void install() {
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, e) -> {
            log("UNCAUGHT on thread " + thread.getName(), e);
            if (old != null) old.uncaughtException(thread, e);
        });
        log("---- app start | abi=" + android.os.Build.SUPPORTED_ABIS[0]
                + " | android=" + android.os.Build.VERSION.SDK_INT
                + " | model=" + android.os.Build.MODEL);
    }
}
