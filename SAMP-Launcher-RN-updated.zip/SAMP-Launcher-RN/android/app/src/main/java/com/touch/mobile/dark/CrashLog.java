package com.touch.mobile.dark;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** يكتب ملف تشخيص: Android/data/<package>/files/launcher_debug.txt */
public class CrashLog {
    private static final String PATH =
            "/storage/emulated/0/Android/data/com.touch.mobile.dark/files/launcher_debug.txt";

    public static synchronized void log(String msg) {
        try {
            File f = new File(PATH);
            File dir = f.getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();
            FileWriter w = new FileWriter(f, true);
            String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            w.write(t + "  " + msg + "\n");
            w.close();
        } catch (Throwable ignored) {
        }
    }

    public static void log(String msg, Throwable e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        log(msg + "\n" + sw);
    }

    public static void install() {
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, e) -> {
            log("UNCAUGHT on thread " + thread.getName(), e);
            if (old != null) old.uncaughtException(thread, e);
        });
        log("---- app start | abi=" + android.os.Build.SUPPORTED_ABIS[0]
                + " | android=" + android.os.Build.VERSION.SDK_INT
                + " | model=" + android.os.Build.MODEL);
    }
}
