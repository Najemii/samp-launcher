package com.touch.mobile.dark;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * يفكّ ملف tombstone (protobuf) بدون أي مكتبة، ويطبع: إشارة الانهيار + رسالة abort
 * + الخيوط التي فيها إطارات من مكتباتنا (libGTASA/libsamp/...) مع العنوان النسبي.
 */
public class CrashTrace {

    static class Field {
        int num; int wire; long v; byte[] raw; Node sub; String str;
    }

    static class Node {
        List<Field> f = new ArrayList<>();
        Field first(int num) { for (Field x : f) if (x.num == num) return x; return null; }
        String str(int num) { Field x = first(num); return x == null ? null : x.str; }
        boolean hasVar(int num) { Field x = first(num); return x != null && x.wire == 0; }
    }

    private static final class Bad extends Exception {}

    private static long[] varint(byte[] d, int p, int e) throws Bad {
        long r = 0; int shift = 0;
        while (p < e && shift < 64) {
            int b = d[p++] & 0xff;
            r |= ((long) (b & 0x7f)) << shift;
            if ((b & 0x80) == 0) return new long[]{r, p};
            shift += 7;
        }
        throw new Bad();
    }

    private static boolean printable(byte[] b) {
        if (b.length == 0) return true;
        for (byte x : b) {
            int c = x & 0xff;
            if (!((c >= 32 && c < 127) || c == 9 || c == 10)) return false;
        }
        return true;
    }

    private static Node parse(byte[] d, int s, int e, int depth) throws Bad {
        Node n = new Node();
        int p = s;
        while (p < e) {
            long[] k = varint(d, p, e);
            p = (int) k[1];
            Field x = new Field();
            x.num = (int) (k[0] >>> 3);
            x.wire = (int) (k[0] & 7);
            if (x.num == 0) throw new Bad();
            if (x.wire == 0) {
                long[] v = varint(d, p, e); x.v = v[0]; p = (int) v[1];
            } else if (x.wire == 1) {
                if (p + 8 > e) throw new Bad();
                long v = 0; for (int i = 7; i >= 0; i--) v = (v << 8) | (d[p + i] & 0xff);
                x.v = v; p += 8;
            } else if (x.wire == 5) {
                if (p + 4 > e) throw new Bad();
                long v = 0; for (int i = 3; i >= 0; i--) v = (v << 8) | (d[p + i] & 0xff);
                x.v = v; p += 4;
            } else if (x.wire == 2) {
                long[] l = varint(d, p, e); p = (int) l[1];
                int len = (int) l[0];
                if (len < 0 || p + len > e) throw new Bad();
                byte[] raw = new byte[len];
                System.arraycopy(d, p, raw, 0, len);
                x.raw = raw;
                if (printable(raw)) {
                    x.str = new String(raw);
                } else if (depth < 12) {
                    try { x.sub = parse(raw, 0, raw.length, depth + 1); } catch (Bad b) { x.sub = null; }
                }
                p += len;
            } else {
                throw new Bad();
            }
            n.f.add(x);
        }
        return n;
    }

    private static boolean isFrame(Node n) {
        String file = n.str(6);
        return n.hasVar(1) && file != null && (file.contains("/") || file.contains(".so"));
    }

    private static String base(String path) {
        int i = path.lastIndexOf('/');
        return i >= 0 ? path.substring(i + 1) : path;
    }

    private static void collectThreads(Node n, List<Node> out) {
        int frames = 0;
        for (Field x : n.f) if (x.sub != null && isFrame(x.sub)) frames++;
        if (frames > 0 && n.hasVar(1)) out.add(n);
        for (Field x : n.f) if (x.sub != null) collectThreads(x.sub, out);
    }

    private static boolean interesting(String file) {
        return file.contains("com.touch.mobile.dark") && file.contains("/lib/")
                || file.endsWith("libc.so") && false;
    }

    public static String dump(byte[] data) {
        StringBuilder sb = new StringBuilder();
        try {
            Node root = parse(data, 0, data.length, 0);
            long tid = root.hasVar(6) ? root.first(6).v : -1;
            sb.append("crash tid=").append(tid).append('\n');
            // نصوص من المستوى الأول + رسالة الإشارة
            for (Field x : root.f) {
                if (x.str != null && x.str.length() < 400 && x.num != 2 && x.num != 4) {
                    sb.append("root#").append(x.num).append(": ").append(x.str).append('\n');
                }
                if (x.sub != null && !isFrame(x.sub)) {
                    boolean small = true;
                    for (Field y : x.sub.f) if (y.sub != null) { small = false; break; }
                    if (small && x.sub.f.size() < 14) {
                        StringBuilder t = new StringBuilder();
                        for (Field y : x.sub.f) {
                            if (y.str != null) t.append(y.num).append("=\"").append(y.str).append("\" ");
                            else if (y.wire == 0 || y.wire == 1) t.append(y.num).append("=0x").append(Long.toHexString(y.v)).append(' ');
                        }
                        if (t.length() > 0) sb.append("info#").append(x.num).append(": ").append(t).append('\n');
                    }
                }
            }
            List<Node> threads = new ArrayList<>();
            collectThreads(root, threads);
            for (Node t : threads) {
                long id = t.first(1).v;
                String name = t.str(2);
                List<String> lines = new ArrayList<>();
                boolean ours = false;
                int idx = 0;
                for (Field x : t.f) {
                    if (x.sub == null || !isFrame(x.sub)) continue;
                    Node fr = x.sub;
                    String file = fr.str(6);
                    String fn = fr.str(4);
                    long rel = fr.first(1).v;
                    boolean o = interesting(file) || (id == tid && idx < 12);
                    if (interesting(file)) ours = true;
                    if (o) lines.add(String.format(Locale.US, "   #%02d %s+0x%x %s", idx, base(file), rel, fn == null ? "" : fn));
                    idx++;
                }
                if (ours || id == tid) {
                    sb.append(id == tid ? "== CRASHED THREAD " : "-- thread ").append(id).append(' ')
                            .append(name == null ? "" : name).append('\n');
                    for (String l : lines) sb.append(l).append('\n');
                }
            }
        } catch (Throwable t) {
            sb.append("decode failed: ").append(t);
        }
        return sb.toString();
    }
}
